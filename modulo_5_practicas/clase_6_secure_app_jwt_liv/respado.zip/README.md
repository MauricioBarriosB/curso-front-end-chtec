# Modulo 5 / Ejercicio Práctico 3 - App Segura / Fecha entrega 03-02-25

URL Github pública acceso compilación para distribución React JS (sitio SPA productivo) :

https://mauriciobarriosb.github.io/curso-front-end-chtec/modulo_5_practicas/clase_6_secure_app_jwt_liv/dist

URL Github pública acceso archivos fuente React JS :

https://github.com/MauricioBarriosB/curso-front-end-chtec/tree/main/modulo_5_practicas/clase_6_secure_app_jwt_liv


# 2 Ejercicio Práctico: Definiendo Tipos e Inferencia

* He creado la función functions/DoctorFunctions.ts con la comprobación de tipos y parámetros, la cual he implementado en el componente DoctorList.tsx

# 3 Definición de Interfaces y Clases en TypeScript

* He creado la clase junto con su interface classes/DoctorClass.ts con la comprobación de tipos, la cual he implementado en el componente DoctorList.tsx

# 4 Implementación Básica en un Componente TS

* Desarrollo componentes TS: DoctorList.tsx, DoctorCard.tsx y Button.tsx (con props tipados y tipos en todos los componentes).

* Carga de Datos de Doctores mediante API Externa en componente DoctorList.tsx: 

https://capacitaenlinea.cl/demodoctorapi/index.php/doctors?key=mab25

