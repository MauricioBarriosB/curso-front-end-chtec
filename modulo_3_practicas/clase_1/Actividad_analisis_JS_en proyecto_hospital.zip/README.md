# Modulo 3 / Tarea práctica # 1 / Actividad Análisis JS en Proyecto Hospital / 12-11-24

Contenido PDF:

* Actividad_analisis_JS_en proyecto_hospital.pdf